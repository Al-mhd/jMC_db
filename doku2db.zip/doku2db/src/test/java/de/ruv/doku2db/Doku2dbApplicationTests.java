package de.ruv.doku2db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Doku2dbApplicationTests {

	@Test
	void contextLoads() {
	}

}
