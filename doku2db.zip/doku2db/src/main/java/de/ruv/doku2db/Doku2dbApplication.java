package de.ruv.doku2db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Doku2dbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Doku2dbApplication.class, args);
	}

}
